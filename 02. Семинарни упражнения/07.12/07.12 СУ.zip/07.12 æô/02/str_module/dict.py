def dict(str1):
    d={}
    for i in str1:
        d[i]=ord(i)
    return d