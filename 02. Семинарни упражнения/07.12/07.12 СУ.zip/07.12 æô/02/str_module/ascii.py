def ascii(str1):
    s=0
    for i in str1:
        a=ord(i)
        s=s+a
    return s