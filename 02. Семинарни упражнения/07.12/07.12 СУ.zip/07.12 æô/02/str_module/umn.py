def umn(str1, n):
    return str1*n