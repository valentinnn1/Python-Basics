def invert(str1):
    return str1[::-1]