from .conc import conc
from .umn import umn
from .invert import invert
from .palindrom import palindrom
from .dict import dict
from .ascii import ascii