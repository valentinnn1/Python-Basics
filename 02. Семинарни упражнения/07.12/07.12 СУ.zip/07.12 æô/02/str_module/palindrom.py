def palindrom(str1):
    if str1==str1[::-1]:
        return "string is palindrom!"
    else:
        return "string isn't palindrom!"