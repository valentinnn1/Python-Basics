def razlika(s1, s2):
    s=s1-s2
    return s