def sechenie(s1, m, n):
    set1=list(s1)
    set2=set1[m:n]
    return set2